<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Dexter Courier | Entregas Malucas</title>
<link href="./css/style.css" rel="stylesheet" type="text/css" />	
<script type="text/javascript" src="./js/jquery.min.js" ></script>
<script type="text/javascript" src="./js/jquery.easing.js" ></script>
<script type="text/javascript" src="./js/jquery.coin-slider.js" ></script>
<script type="text/javascript" src="./js/custom.js" ></script>
</head>
<body>

<div class="full">

<div id="header" >
<a href="#"><img src="./img/markonelogo.png" alt="" height="60" width="280" /></a>
<ul class="menu">
	<li><a href="#">Contato<span>fale conosco</span></a></li>
	<li><a href="#">Servi&ccedil;os<span>Entregas</span></a></li>
	<li><a href="#">Sobre<span>quem somos</span></a></li>
	<li class="first selected"><a href="#">Home<span>p&aacute;gina inicial</span></a></li>
</ul>
	</div>
	
	<!-- Slider Begin -->
	<div id="slider-full">
		<ul id="fullSlides">
			<li>
	<img src="./img/slides/01_slide_big.png" alt="slide01" />
				<div>
	<a href="#" rel="article">Logo 4Linux</a>
	<img src="./img/slides/logo4linuxsmall.png" alt="" />
		<p>
	<span><b>Esse é apenas um site ilustrativo criado para os treinamentos da 4Linux.</b></span>
	<span><b>Qualquer semelhança é mera coincidência!</b></span>
		</p>
		</div>
		</li>
			<li>
	<img src="./img/slides/2.png" alt="slide01" />
				<div>
	<a href="#" rel="article">Logo 4Linux</a>
	<img src="./img/slides/logo4linuxsmall.png" alt="" />
		<p>
	<span><b>Esse é apenas um site ilustrativo criado para os treinamentos da 4Linux.</b></span>
	<span><b>Qualquer semelhança é mera coincidência!</b></span>
		</p>
		</div>
		</li>
		</ul>
		<div class="labels">
			<div class="labelWrapp">
				<div class="innerLabel"><a href="#">&nbsp;</a></div>
				<p>&nbsp;</p>
			</div>
		</div>
		
		<div class="pager"></div>
	</div>
	<div class="container clearfix">
		<div id="menu">
		<div class="medium">
		<h2 class="title">Principais Clientes</h2>
		<p> * 4Linux </p>
		<p> * Dee Dee Turismo</p>
		<p> * Levinsky Corretora</p>
		<p> * Mordechai Advogados</p>
		</div>
					
		<div class="medium">
		<h2 class="title">Nossos Serviços</h2>
		<p>Dexter Motoboy</p>
		<p>Dexter Carroboy</p>
		<p>Dexter DDD</p>
		<p>Dexter DDI</p>
		</div>
		</div>
		<div id="content">
		<div class="section">
		<div class="large article">
		<h3><a href="#">A Dexter Courier</a></h3>
		<img src="./img/a1.jpg" alt="" align="right" />
		<p align="justify">A Dexter Courier – Entregas Malucas nasceu a partir de fatos do cotidiano. Assim como tudo na vida, ser o caçula da família tem um lado bom e outro lado nem tão bom assim.
		<p align="justify">Durante toda a minha adolescência, eu vivia tendo que fazer favores e mais favores para meus pais como entregar documentos no escritório do meu tio, comprar fraudas para meu primo que acabara de nascer e levá-las até a casa de minha tia, comprar fast food para os almoços atordoadas de meu pai e muitas outras coisas</p>
		<p align="justify">Não bastando, tinha minha irmã mais velha que, sempre aproveitando-se da situação, também me mandava entregar e buscar livros na biblioteca da faculdade e me fazer de “pombo correio” levando e trazendo recadinhos, lições de casa e docinhos para o namorado e as amigas.  </p>

<p align="justify">Diante deste cenário todo e aliado ao fato de que eu tinha crescido e, definitivamente, precisava de um trabalho, foi que surgiu a ideia inicial de criar uma empresa que prestasse esses tipos de serviços não apenas para familiares e amigos próximos, como também para outras pessoas que diariamente necessitam desses serviços.</p>
<p align="justify">Hoje, a Dexter Courier – Entregas Malucas é uma empresa de logística que preza a qualidade de serviço. Seu principal objetivo é prestar serviços de coleta e entrega com rapidez e qualidade, garantindo que seu produto, objeto, documento ou seja lá o que for, chegue ao local de destino intacto, em segurança e no tempo desejado.</p>
		</div>
					
		</div>	
		</div>
		</div>
	
	<div id="footer" class="clearfix">
		
		<div class="section clearfix">
		</div>
		
		<div class="shadow-bottom"></div>
		
		<span class="credits">&copy; 2011 <strong>Dexter Courier - Entregas Malucas</strong> - Todos os direitos reservados. </span>
	</div>
</div>
</body>
</html>
