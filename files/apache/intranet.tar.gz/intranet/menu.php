<ul id="imenu">
	<li><a href="index.php" title="Home"><img src="menu/home.png" /></a></li>
	<li><a href="clientes.php" title="Clientes"><img src="menu/empresas.png" /></a></li>
	<li><a href="organograma.php" title="Organograma"><img src="menu/stats.png" /></a></li>
	<li><a href="funcionarios.php" title="Funcion&aacute;rios"><img src="menu/usuarios.png" /></a></li>
	<li><a href="agenda.php" title="Calend&aacute;rio"><img src="menu/agenda.png" /></a></li>
	<li><a href="backup.php" title="Backup"><img src="menu/backup.png" /></a></li>
</ul>
