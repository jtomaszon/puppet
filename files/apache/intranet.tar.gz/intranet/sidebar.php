        <div class="sidebar">
		
		<div class="block">
			<h2>Carros em Circula��o</h2>
			<ul class="block_mais">
				<li><strong>Fiesta Courier</strong> - Placa: TUX2468</li>
				<li><strong>Ford Courier Van</strong>- Placa: GNU2167</li>
				<li class="final"><strong>Yamaha Fazer</strong> - Placa: GPL3761</li>
			</ul>
		</div>
		<div class="block">
			<h3>Feito por:</h3>
                       <a href="http://www.4linux.com.br" title="4Linux"><img src="images/logo4linuxsmall.png" alt="4Linux - Curso e Consultoria Linux" /></a>
		</div>
		
	</div>
