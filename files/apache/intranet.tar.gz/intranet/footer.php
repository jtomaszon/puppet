	<div id="grid_footer">
		<div class="grid_footer_center">	
			<p>&copy;2011 4Linux. Todos os direitos reservados.</p>
		</div>
	</div>

</body>
</html>